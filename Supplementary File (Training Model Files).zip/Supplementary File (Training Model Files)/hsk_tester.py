import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import pickle
import warnings
warnings.filterwarnings('ignore')

# 设备配置
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 直接从您的训练代码复制模型配置
OPTIMIZED_CONFIG = {
    'vocab_size': 60000,
    'embed_dim': 300,
    'hidden_dim': 384,
    'num_layers': 3,
    'dropout': 0.4,
    'num_classes': 7,
    'conv_channels': 128,
    'attention_heads': 8,
}

# 复制模型定义
class OptimizedHSKClassifier(nn.Module):
    def __init__(self, config=OPTIMIZED_CONFIG):
        super().__init__()
        self.config = config
        
        self.embedding = nn.Embedding(config['vocab_size'], config['embed_dim'], padding_idx=0)
        self.embed_dropout = nn.Dropout(0.1)
        self.pos_encoding = nn.Parameter(torch.randn(1, 200, config['embed_dim']))
        
        self.conv_layers = nn.ModuleList([
            nn.Sequential(
                nn.Conv1d(config['embed_dim'], config['conv_channels'], 2, padding=1),
                nn.BatchNorm1d(config['conv_channels']),
                nn.GELU(),
                nn.Dropout(0.1)
            ),
            nn.Sequential(
                nn.Conv1d(config['embed_dim'], config['conv_channels'], 3, padding=1),
                nn.BatchNorm1d(config['conv_channels']),
                nn.GELU(),
                nn.Dropout(0.1)
            ),
            nn.Sequential(
                nn.Conv1d(config['embed_dim'], config['conv_channels'], 4, padding=2),
                nn.BatchNorm1d(config['conv_channels']),
                nn.GELU(),
                nn.Dropout(0.1)
            )
        ])
        
        self.lstm = nn.LSTM(
            config['embed_dim'],
            config['hidden_dim'] // 2,
            batch_first=True,
            bidirectional=True,
            num_layers=config['num_layers'],
            dropout=0.2
        )
        self.lstm_norm = nn.LayerNorm(config['hidden_dim'])
        
        self.self_attention = nn.MultiheadAttention(
            config['hidden_dim'],
            num_heads=config['attention_heads'],
            dropout=0.1,
            batch_first=True
        )
        self.attention_norm = nn.LayerNorm(config['hidden_dim'])
        
        conv_features_dim = config['conv_channels'] * len(self.conv_layers) * 2
        lstm_features_dim = config['hidden_dim'] * 3
        total_features = conv_features_dim + lstm_features_dim
        
        print(f"特征维度: 卷积{conv_features_dim} + LSTM{lstm_features_dim} = 总{total_features}")
        
        self.feature_fusion = nn.Sequential(
            nn.Linear(total_features, 768),
            nn.BatchNorm1d(768),
            nn.GELU(),
            nn.Dropout(0.3),
            nn.Linear(768, 384),
            nn.BatchNorm1d(384),
            nn.GELU(),
            nn.Dropout(0.2),
            nn.Linear(384, 192),
            nn.BatchNorm1d(192),
            nn.GELU(),
            nn.Dropout(0.1),
        )
        
        # 主分类器
        self.main_classifier = nn.Sequential(
            nn.Linear(192, 96),
            nn.BatchNorm1d(96),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(96, config['num_classes'])
        )
        
        # 添加辅助分类器 - 这是缺失的部分！
        self.aux_classifier = nn.Sequential(
            nn.Linear(192, 64),
            nn.GELU(),
            nn.Linear(64, config['num_classes'])
        )
        
    def forward(self, input_ids, attention_mask=None, use_aux=False):
        batch_size, seq_len = input_ids.shape
        
        x = self.embedding(input_ids)
        if seq_len <= 200:
            x = x + self.pos_encoding[:, :seq_len, :]
        x = self.embed_dropout(x)
        
        x_transposed = x.transpose(1, 2)
        conv_features = []
        
        for conv in self.conv_layers:
            conv_out = conv(x_transposed)
            max_pool = F.adaptive_max_pool1d(conv_out, 1).squeeze(-1)
            avg_pool = F.adaptive_avg_pool1d(conv_out, 1).squeeze(-1)
            conv_features.extend([max_pool, avg_pool])
        
        conv_combined = torch.cat(conv_features, dim=1)
        
        lstm_out, (hidden, _) = self.lstm(x)
        lstm_out = self.lstm_norm(lstm_out)
        
        if attention_mask is not None:
            key_padding_mask = ~attention_mask.bool()
        else:
            key_padding_mask = None
            
        attn_out, attn_weights = self.self_attention(
            lstm_out, lstm_out, lstm_out,
            key_padding_mask=key_padding_mask
        )
        attn_out = self.attention_norm(lstm_out + attn_out)
        
        max_pool = torch.max(attn_out, dim=1)[0]
        avg_pool = torch.mean(attn_out, dim=1)
        
        if hidden.dim() == 3:
            forward_final = hidden[-2, :, :]
            backward_final = hidden[-1, :, :]
            lstm_final = torch.cat([forward_final, backward_final], dim=1)
        else:
            lstm_final = avg_pool
        
        lstm_features = torch.cat([max_pool, avg_pool, lstm_final], dim=1)
        all_features = torch.cat([conv_combined, lstm_features], dim=1)
        
        fused_features = self.feature_fusion(all_features)
        
        # 主分类
        main_logits = self.main_classifier(fused_features)
        
        if use_aux:
            aux_logits = self.aux_classifier(fused_features)
            return main_logits, aux_logits
        
        return main_logits
class CustomTokenizer:
    def __init__(self, vocab_size=60000):
        self.vocab_size = vocab_size
        self.word2idx = {'<PAD>': 0, '<UNK>': 1}
        self.idx2word = {0: '<PAD>', 1: '<UNK>'}
        
    def encode(self, text, max_length=200):
        words = list(text.strip())
        input_ids = [self.word2idx.get(word, 1) for word in words]
        
        if len(input_ids) > max_length:
            input_ids = input_ids[:max_length]
        else:
            input_ids = input_ids + [0] * (max_length - len(input_ids))
        
        attention_mask = [1 if token_id != 0 else 0 for token_id in input_ids]
        
        return {
            'input_ids': torch.tensor(input_ids, dtype=torch.long),
            'attention_mask': torch.tensor(attention_mask, dtype=torch.long)
        }

class HSKTextPredictor:
    def __init__(self, model_path='best_optimized_model.pth'):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = None
        self.tokenizer = None
        self.level_names = ['HSK1', 'HSK2', 'HSK3', 'HSK4', 'HSK5', 'HSK6', 'HSK7-9']
        
        if os.path.exists(model_path):
            self.load_model(model_path)
        else:
            print(f"⚠️ 未找到模型文件: {model_path}")
            print("请先运行训练程序生成模型文件")
    
    def load_model(self, model_path):
        try:
            checkpoint = torch.load(model_path, map_location=self.device, weights_only=False)
            model_config = checkpoint['config']
            
            self.model = OptimizedHSKClassifier(model_config)
            self.model.load_state_dict(checkpoint['model_state_dict'])
            self.model.to(self.device)
            self.model.eval()
            
            tokenizer_path = model_path.replace('.pth', '_tokenizer.pkl')
            if os.path.exists(tokenizer_path):
                with open(tokenizer_path, 'rb') as f:
                    self.tokenizer = pickle.load(f)
            else:
                print("⚠️ 未找到分词器文件，将使用默认分词器")
                self.tokenizer = CustomTokenizer()
            
            print(f"✅ 模型加载成功! 准确率: {checkpoint['accuracy']:.4f}")
            
        except Exception as e:
            print(f"❌ 模型加载失败: {e}")
    
    def predict_text(self, text):
        if self.model is None:
            raise ValueError("模型未加载")
        
        if self.tokenizer is None:
            raise ValueError("分词器未加载")
        
        encoding = self.tokenizer.encode(text)
        input_ids = encoding['input_ids'].unsqueeze(0).to(self.device)
        attention_mask = encoding['attention_mask'].unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            outputs = self.model(input_ids, attention_mask)
            probabilities = F.softmax(outputs, dim=1)
            predicted_level_idx = torch.argmax(outputs, 1).item()
            confidence = torch.max(probabilities).item()
        
        result = {
            'predicted_level': self.level_names[predicted_level_idx],
            'confidence': confidence,
            'probabilities': {}
        }
        
        for i, level in enumerate(self.level_names):
            result['probabilities'][level] = probabilities[0][i].item()
        
        return result

def main():
    import sys
    
    print("🎯 HSK文本分级测试工具")
    print("=" * 50)
    
    # 检查模型文件是否存在
    model_file = 'best_optimized_model.pth'
    tokenizer_file = 'best_optimized_model_tokenizer.pkl'
    
    if not os.path.exists(model_file):
        print(f"❌ 未找到模型文件: {model_file}")
        print("请先运行训练程序")
        return
    
    if not os.path.exists(tokenizer_file):
        print(f"❌ 未找到分词器文件: {tokenizer_file}")
        print("请先运行训练程序")
        return
    
    # 初始化预测器
    predictor = HSKTextPredictor(model_file)
    
    # 命令行参数处理
    if len(sys.argv) > 1:
        # 直接测试命令行参数中的文本
        text = ' '.join(sys.argv[1:])
        print(f"📝 测试文本: {text}")
        print("-" * 50)
        
        result = predictor.predict_text(text)
        
        print(f"🎯 预测级别: {result['predicted_level']}")
        print(f"📊 置信度: {result['confidence']:.2%}")
        print("\n📈 详细概率:")
        for level, prob in sorted(result['probabilities'].items(), 
                                key=lambda x: x[1], reverse=True):
            bar = "█" * int(prob * 30)
            print(f"  {level}: {prob:6.2%} {bar}")
    else:
        # 交互模式
        print("交互模式 - 输入中文文本进行测试")
        print("输入 'quit' 或 'exit' 退出")
        print("=" * 50)
        
        while True:
            try:
                text = input("\n请输入中文文本: ").strip()
                
                if text.lower() in ['quit', 'exit', '退出', 'q']:
                    print("👋 再见！")
                    break
                    
                if not text:
                    print("⚠️ 请输入有效文本")
                    continue
                
                print("-" * 40)
                result = predictor.predict_text(text)
                
                print(f"📝 文本: {text}")
                print(f"🎯 预测: {result['predicted_level']}")
                print(f"📊 置信度: {result['confidence']:.2%}")
                print("📈 概率分布:")
                
                for level, prob in sorted(result['probabilities'].items(), 
                                        key=lambda x: x[1], reverse=True):
                    print(f"  {level}: {prob:6.2%}")
                    
            except KeyboardInterrupt:
                print("\n👋 用户中断，再见！")
                break
            except Exception as e:
                print(f"❌ 错误: {e}")

if __name__ == "__main__":
    main()