import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report
import numpy as np
from tqdm import tqdm
import warnings
from collections import Counter
import json
import random
from transformers import get_cosine_schedule_with_warmup
import torch.nn.functional as F
import pickle
warnings.filterwarnings('ignore')

# 设备配置
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# 优化配置
OPTIMIZED_CONFIG = {
    'vocab_size': 60000,
    'embed_dim': 300,
    'hidden_dim': 384,
    'num_layers': 3,
    'dropout': 0.4,
    'num_classes': 7,
    'conv_channels': 128,
    'attention_heads': 8,
}

class OptimizedHSKClassifier(nn.Module):
    """优化的HSK分类器"""
    def __init__(self, config=OPTIMIZED_CONFIG):
        super().__init__()
        self.config = config
        
        # 词嵌入 - 添加位置编码
        self.embedding = nn.Embedding(config['vocab_size'], config['embed_dim'], padding_idx=0)
        self.embed_dropout = nn.Dropout(0.1)
        
        # 位置编码
        self.pos_encoding = nn.Parameter(torch.randn(1, 200, config['embed_dim']))
        
        # 多尺度卷积 - 改进结构
        self.conv_layers = nn.ModuleList([
            nn.Sequential(
                nn.Conv1d(config['embed_dim'], config['conv_channels'], 2, padding=1),
                nn.BatchNorm1d(config['conv_channels']),
                nn.GELU(),
                nn.Dropout(0.1)
            ),
            nn.Sequential(
                nn.Conv1d(config['embed_dim'], config['conv_channels'], 3, padding=1),
                nn.BatchNorm1d(config['conv_channels']),
                nn.GELU(),
                nn.Dropout(0.1)
            ),
            nn.Sequential(
                nn.Conv1d(config['embed_dim'], config['conv_channels'], 4, padding=2),
                nn.BatchNorm1d(config['conv_channels']),
                nn.GELU(),
                nn.Dropout(0.1)
            )
        ])
        
        # BiLSTM - 添加层归一化
        self.lstm = nn.LSTM(
            config['embed_dim'],
            config['hidden_dim'] // 2,
            batch_first=True,
            bidirectional=True,
            num_layers=config['num_layers'],
            dropout=0.2
        )
        self.lstm_norm = nn.LayerNorm(config['hidden_dim'])
        
        # 多头注意力 - 确保维度可整除
        self.self_attention = nn.MultiheadAttention(
            config['hidden_dim'],
            num_heads=config['attention_heads'],
            dropout=0.1,
            batch_first=True
        )
        self.attention_norm = nn.LayerNorm(config['hidden_dim'])
        
        # 特征融合 - 重新计算维度
        conv_features_dim = config['conv_channels'] * len(self.conv_layers) * 2
        lstm_features_dim = config['hidden_dim'] * 3
        total_features = conv_features_dim + lstm_features_dim
        
        print(f"特征维度: 卷积{conv_features_dim} + LSTM{lstm_features_dim} = 总{total_features}")
        
        # 改进的特征融合
        self.feature_fusion = nn.Sequential(
            nn.Linear(total_features, 768),
            nn.BatchNorm1d(768),
            nn.GELU(),
            nn.Dropout(0.3),
            
            nn.Linear(768, 384),
            nn.BatchNorm1d(384),
            nn.GELU(),
            nn.Dropout(0.2),
            
            nn.Linear(384, 192),
            nn.BatchNorm1d(192),
            nn.GELU(),
            nn.Dropout(0.1),
        )
        
        # 主分类器
        self.main_classifier = nn.Sequential(
            nn.Linear(192, 96),
            nn.BatchNorm1d(96),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(96, config['num_classes'])
        )
        
        # 辅助分类器 - 简化
        self.aux_classifier = nn.Sequential(
            nn.Linear(192, 64),
            nn.GELU(),
            nn.Linear(64, config['num_classes'])
        )
        
        self._init_weights()
    
    def _init_weights(self):
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.kaiming_normal_(module.weight, mode='fan_in', nonlinearity='leaky_relu')
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
            elif isinstance(module, nn.Embedding):
                nn.init.normal_(module.weight, mean=0, std=0.02)
            elif isinstance(module, nn.LSTM):
                for name, param in module.named_parameters():
                    if 'weight' in name:
                        nn.init.orthogonal_(param)
                    elif 'bias' in name:
                        nn.init.constant_(param, 0)
    
    def forward(self, input_ids, attention_mask=None, use_aux=False):
        batch_size, seq_len = input_ids.shape
        
        # 词嵌入 + 位置编码
        x = self.embedding(input_ids)
        if seq_len <= 200:
            x = x + self.pos_encoding[:, :seq_len, :]
        x = self.embed_dropout(x)
        
        # 多尺度卷积特征
        x_transposed = x.transpose(1, 2)
        conv_features = []
        
        for conv in self.conv_layers:
            conv_out = conv(x_transposed)
            max_pool = F.adaptive_max_pool1d(conv_out, 1).squeeze(-1)
            avg_pool = F.adaptive_avg_pool1d(conv_out, 1).squeeze(-1)
            conv_features.extend([max_pool, avg_pool])
        
        conv_combined = torch.cat(conv_features, dim=1)
        
        # LSTM序列编码
        lstm_out, (hidden, _) = self.lstm(x)
        lstm_out = self.lstm_norm(lstm_out)
        
        # 多头注意力
        if attention_mask is not None:
            key_padding_mask = ~attention_mask.bool()
        else:
            key_padding_mask = None
            
        attn_out, attn_weights = self.self_attention(
            lstm_out, lstm_out, lstm_out,
            key_padding_mask=key_padding_mask
        )
        attn_out = self.attention_norm(lstm_out + attn_out)
        
        # 多尺度LSTM特征池化
        max_pool = torch.max(attn_out, dim=1)[0]
        avg_pool = torch.mean(attn_out, dim=1)
        
        # LSTM最终状态
        if hidden.dim() == 3:
            forward_final = hidden[-2, :, :]
            backward_final = hidden[-1, :, :]
            lstm_final = torch.cat([forward_final, backward_final], dim=1)
        else:
            lstm_final = avg_pool
        
        # 特征融合
        lstm_features = torch.cat([max_pool, avg_pool, lstm_final], dim=1)
        all_features = torch.cat([conv_combined, lstm_features], dim=1)
        
        # 特征融合
        fused_features = self.feature_fusion(all_features)
        
        # 主分类
        main_logits = self.main_classifier(fused_features)
        
        if use_aux:
            aux_logits = self.aux_classifier(fused_features)
            return main_logits, aux_logits
        
        return main_logits

# ==================== 推理功能模块 ====================
class HSKTextPredictor:
    """HSK文本预测器 - 用于推理"""
    
    def __init__(self, model_path='best_optimized_model.pth'):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = None
        self.tokenizer = None
        self.level_names = ['HSK1', 'HSK2', 'HSK3', 'HSK4', 'HSK5', 'HSK6', 'HSK7-9']
        
        if os.path.exists(model_path):
            self.load_model(model_path)
        else:
            print(f"⚠️ 未找到模型文件: {model_path}")
            print("请先运行训练程序生成模型文件")
    
    def load_model(self, model_path):
        """加载训练好的模型"""
        try:
            # 加载检查点
            checkpoint = torch.load(model_path, map_location=self.device, weights_only=False)
            model_config = checkpoint['config']
            
            # 创建模型
            self.model = OptimizedHSKClassifier(model_config)
            self.model.load_state_dict(checkpoint['model_state_dict'])
            self.model.to(self.device)
            self.model.eval()
            
            # 加载分词器（如果有的话）
            tokenizer_path = model_path.replace('.pth', '_tokenizer.pkl')
            if os.path.exists(tokenizer_path):
                with open(tokenizer_path, 'rb') as f:
                    self.tokenizer = pickle.load(f)
            else:
                print("⚠️ 未找到分词器文件，将使用默认分词器")
                self.tokenizer = CustomTokenizer()
            
            print(f"✅ 模型加载成功! 准确率: {checkpoint['accuracy']:.4f}")
            
        except Exception as e:
            print(f"❌ 模型加载失败: {e}")
    
    def predict_text(self, text):
        """
        预测文本的HSK等级和概率
        返回: {
            'predicted_level': 'HSK6', 
            'confidence': 0.9345,
            'probabilities': {
                'HSK1': 0.0002, 
                'HSK2': 0.0015,
                ...
            }
        }
        """
        if self.model is None:
            raise ValueError("模型未加载，请先调用load_model()")
        
        if self.tokenizer is None:
            raise ValueError("分词器未加载")
        
        # 预处理文本
        encoding = self.tokenizer.encode(text)
        input_ids = encoding['input_ids'].unsqueeze(0).to(self.device)
        attention_mask = encoding['attention_mask'].unsqueeze(0).to(self.device)
        
        # 推理
        with torch.no_grad():
            outputs = self.model(input_ids, attention_mask)
            probabilities = F.softmax(outputs, dim=1)
            predicted_level_idx = torch.argmax(outputs, 1).item()
            confidence = torch.max(probabilities).item()
        
        # 构建结果
        result = {
            'predicted_level': self.level_names[predicted_level_idx],
            'confidence': confidence,
            'probabilities': {}
        }
        
        # 添加所有级别的概率
        for i, level in enumerate(self.level_names):
            result['probabilities'][level] = probabilities[0][i].item()
        
        return result
    
    def analyze_text_batch(self, texts):
        """批量分析文本"""
        results = []
        for text in texts:
            try:
                result = self.predict_text(text)
                results.append({
                    'text': text,
                    **result
                })
            except Exception as e:
                results.append({
                    'text': text,
                    'error': str(e)
                })
        return results

# ==================== 保存分词器函数 ====================
def save_tokenizer(tokenizer, filepath):
    """保存分词器"""
    with open(filepath, 'wb') as f:
        pickle.dump(tokenizer, f)
    print(f"💾 分词器已保存: {filepath}")

# ==================== 数据加载函数 ====================
def load_balanced_hsk_data(base_path):
    """平衡数据加载"""
    texts = []
    labels = []
    
    print("正在加载HSK数据...")
    
    level_mapping = {
        '初级（1-3级）': {'1级': 0, '2级': 1, '3级': 2},
        '中级（4-6级）': {'4级': 3, '5级': 4, '6级': 5},
        '高级（7-9级）': {'7-9级': 6}
    }
    
    level_counts = {i: 0 for i in range(7)}
    
    for main_level, sub_levels in level_mapping.items():
        main_level_path = os.path.join(base_path, main_level)
        if not os.path.exists(main_level_path):
            continue
            
        for sub_level, label in sub_levels.items():
            if main_level == '高级（7-9级）':
                # 对高级别数据增强
                for item in os.listdir(main_level_path):
                    item_path = os.path.join(main_level_path, item)
                    if os.path.isdir(item_path):
                        _load_texts_with_augmentation(item_path, texts, labels, label, augmentation=3)
            else:
                sub_level_path = os.path.join(main_level_path, sub_level)
                if os.path.exists(sub_level_path):
                    _load_texts_with_augmentation(sub_level_path, texts, labels, label, augmentation=1)
    
    # 平衡数据
    level_names = ['HSK1', 'HSK2', 'HSK3', 'HSK4', 'HSK5', 'HSK6', 'HSK7-9']
    label_counts = np.bincount(labels)
    print("原始数据分布:")
    for i in range(7):
        print(f"  {level_names[i]}: {label_counts[i]} 个样本")
    
    # 简单平衡 - 目标800个样本
    level_texts = {i: [] for i in range(7)}
    for text, label in zip(texts, labels):
        level_texts[label].append(text)
    
    balanced_texts = []
    balanced_labels = []
    target_samples = 800
    
    for label in range(7):
        current_texts = level_texts[label]
        if len(current_texts) < target_samples:
            # 过采样
            multiplier = (target_samples // len(current_texts)) + 1
            augmented = []
            for text in current_texts:
                augmented.extend(_enhanced_augment(text, multiplier))
            current_texts.extend(augmented[:target_samples - len(current_texts)])
        
        if len(current_texts) > target_samples:
            current_texts = random.sample(current_texts, target_samples)
        
        balanced_texts.extend(current_texts)
        balanced_labels.extend([label] * len(current_texts))
    
    # 打乱
    combined = list(zip(balanced_texts, balanced_labels))
    random.shuffle(combined)
    balanced_texts, balanced_labels = zip(*combined)
    
    print(f"总共加载 {len(balanced_texts)} 个平衡样本")
    return list(balanced_texts), list(balanced_labels)

def _load_texts_with_augmentation(directory_path, texts, labels, label, augmentation=1):
    """加载文本并增强"""
    for item in os.listdir(directory_path):
        item_path = os.path.join(directory_path, item)
        
        if os.path.isdir(item_path):
            _load_texts_with_augmentation(item_path, texts, labels, label, augmentation)
        elif item.endswith('.txt'):
            try:
                with open(item_path, 'r', encoding='utf-8', errors='ignore') as f:
                    text = f.read().strip()
                
                text = text.replace('\n', ' ').replace('\r', ' ').strip()
                if len(text) >= 10:
                    texts.append(text)
                    labels.append(label)
                    
                    # 简单增强
                    if augmentation > 0 and len(text) > 15:
                        augmented = _enhanced_augment(text, augmentation)
                        texts.extend(augmented)
                        labels.extend([label] * len(augmented))
                    
            except Exception as e:
                continue

def _enhanced_augment(text, num_variants):
    """增强的数据增强"""
    if len(text) < 15:
        return []
    
    variants = []
    chars = list(text)
    
    for _ in range(num_variants):
        new_chars = chars.copy()
        
        # 多种增强策略
        if random.random() < 0.4 and len(new_chars) > 20:
            # 随机删除1-2个字符
            delete_count = random.randint(1, 2)
            for _ in range(delete_count):
                if len(new_chars) > 15:
                    del_idx = random.randint(0, len(new_chars)-1)
                    del new_chars[del_idx]
        
        if random.random() < 0.4 and len(new_chars) > 15:
            # 随机交换相邻字符
            swap_count = random.randint(1, 2)
            for _ in range(swap_count):
                if len(new_chars) >= 2:
                    idx = random.randint(0, len(new_chars)-2)
                    new_chars[idx], new_chars[idx+1] = new_chars[idx+1], new_chars[idx]
        
        if random.random() < 0.2 and len(new_chars) > 10:
            # 随机重复一个字符
            repeat_idx = random.randint(0, len(new_chars)-1)
            new_chars.insert(repeat_idx, new_chars[repeat_idx])
        
        new_text = ''.join(new_chars)
        if len(new_text) >= 10 and new_text != text:
            variants.append(new_text)
    
    return variants[:num_variants]

# ==================== 其他必要的类 ====================
class CustomTokenizer:
    def __init__(self, vocab_size=60000):
        self.vocab_size = vocab_size
        self.word2idx = {'<PAD>': 0, '<UNK>': 1}
        self.idx2word = {0: '<PAD>', 1: '<UNK>'}
        
    def build_vocab(self, texts):
        print("构建词汇表...")
        word_freq = Counter()
        
        for text in tqdm(texts):
            words = list(text.strip())
            word_freq.update(words)
        
        most_common = word_freq.most_common(self.vocab_size - 2)
        
        for idx, (word, freq) in enumerate(most_common, start=2):
            self.word2idx[word] = idx
            self.idx2word[idx] = word
        
        print(f"词汇表大小: {len(self.word2idx)}")
    
    def encode(self, text, max_length=200):
        words = list(text.strip())
        input_ids = [self.word2idx.get(word, 1) for word in words]
        
        if len(input_ids) > max_length:
            input_ids = input_ids[:max_length]
        else:
            input_ids = input_ids + [0] * (max_length - len(input_ids))
        
        attention_mask = [1 if token_id != 0 else 0 for token_id in input_ids]
        
        return {
            'input_ids': torch.tensor(input_ids, dtype=torch.long),
            'attention_mask': torch.tensor(attention_mask, dtype=torch.long)
        }

class HSKDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_length=200):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        encoding = self.tokenizer.encode(self.texts[idx], self.max_length)
        return {
            'input_ids': encoding['input_ids'],
            'attention_mask': encoding['attention_mask'],
            'labels': torch.tensor(self.labels[idx], dtype=torch.long)
        }

# ==================== 改进的训练函数 ====================
def train_optimized_model():
    """优化的训练函数"""
    base_path = r"C:\Users\DF-Lenovo\Desktop\李思卫五套教材（分级后教材_已过滤）"
    texts, labels = load_balanced_hsk_data(base_path)
    
    if len(texts) == 0:
        print("未找到数据")
        return None, None, 0
    
    # 数据划分
    train_texts, temp_texts, train_labels, temp_labels = train_test_split(
        texts, labels, test_size=0.2, random_state=42, stratify=labels
    )
    
    val_texts, test_texts, val_labels, test_labels = train_test_split(
        temp_texts, temp_labels, test_size=0.5, random_state=42, stratify=temp_labels
    )
    
    print(f"训练集: {len(train_texts)} 个样本")
    print(f"验证集: {len(val_texts)} 个样本")
    print(f"测试集: {len(test_texts)} 个样本")
    
    # 初始化分词器
    tokenizer = CustomTokenizer(vocab_size=60000)
    tokenizer.build_vocab(train_texts)
    
    # 更新模型配置
    model_config = OPTIMIZED_CONFIG.copy()
    model_config['vocab_size'] = len(tokenizer.word2idx)
    model_config['num_classes'] = 7
    
    # 创建数据集
    train_dataset = HSKDataset(train_texts, train_labels, tokenizer)
    val_dataset = HSKDataset(val_texts, val_labels, tokenizer)
    test_dataset = HSKDataset(test_texts, test_labels, tokenizer)
    
    # 数据加载器 - 调整batch_size
    train_loader = DataLoader(train_dataset, batch_size=24, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=48, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=48, shuffle=False)
    
    # 初始化模型
    model = OptimizedHSKClassifier(model_config).to(device)
    
    # 计算参数
    total_params = sum(p.numel() for p in model.parameters())
    print(f"总参数: {total_params:,}")
    
    # 优化器
    optimizer = optim.AdamW(
        model.parameters(),
        lr=3e-4,
        weight_decay=1e-4,
        betas=(0.9, 0.999)
    )
    
    # 学习率调度
    total_steps = len(train_loader) * 60
    scheduler = get_cosine_schedule_with_warmup(
        optimizer,
        num_warmup_steps=len(train_loader) * 2,
        num_training_steps=total_steps
    )
    
    # 改进的损失函数
    class OptimizedLoss(nn.Module):
        def __init__(self, alpha=None, gamma=2.0, smoothing=0.1, aux_weight=0.2):
            super().__init__()
            self.gamma = gamma
            self.smoothing = smoothing
            self.alpha = alpha
            self.aux_weight = aux_weight
        
        def forward(self, main_outputs, aux_outputs, targets):
            # 焦点损失
            log_probs = F.log_softmax(main_outputs, dim=-1)
            probs = torch.exp(log_probs)
            
            # 焦点权重
            pt = probs.gather(1, targets.unsqueeze(1)).squeeze()
            focal_weight = (1 - pt) ** self.gamma
            
            # 标签平滑的交叉熵
            confidence = 1.0 - self.smoothing
            smooth_labels = torch.full_like(main_outputs, self.smoothing / (main_outputs.size(-1) - 1))
            smooth_labels.scatter_(1, targets.unsqueeze(1), confidence)
            
            if self.alpha is not None:
                alpha = self.alpha[targets]
                main_loss = -alpha * focal_weight * (log_probs * smooth_labels).sum(dim=1)
            else:
                main_loss = -focal_weight * (log_probs * smooth_labels).sum(dim=1)
            
            main_loss = main_loss.mean()
            
            # 简化的辅助损失
            aux_loss = F.cross_entropy(aux_outputs, targets, label_smoothing=0.1)
            
            return main_loss + self.aux_weight * aux_loss
    
    # 计算类别权重
    label_counts = np.bincount(train_labels)
    class_weights = torch.tensor(1.0 / np.sqrt(label_counts + 1e-8), dtype=torch.float32).to(device)
    class_weights = class_weights / class_weights.sum() * len(class_weights)
    
    criterion = OptimizedLoss(alpha=class_weights, gamma=2.0, smoothing=0.1, aux_weight=0.2)
    
    # 训练循环优化
    best_accuracy = 0
    patience = 15
    patience_counter = 0
    best_epoch = 0
    
    print("\n开始优化训练...")
    
    for epoch in range(60):
        model.train()
        total_loss = 0
        correct = 0
        total = 0
        
        progress_bar = tqdm(train_loader, desc=f'Epoch {epoch+1}/60')
        
        for batch in progress_bar:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)
            
            optimizer.zero_grad()
            main_outputs, aux_outputs = model(input_ids, attention_mask, use_aux=True)
            
            loss = criterion(main_outputs, aux_outputs, labels)
            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
            
            total_loss += loss.item()
            _, predicted = torch.max(main_outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
            progress_bar.set_postfix({
                'Loss': f'{loss.item():.4f}',
                'Acc': f'{correct/total:.4f}',
                'LR': f'{optimizer.param_groups[0]["lr"]:.2e}'
            })
        
        avg_loss = total_loss / len(train_loader)
        train_accuracy = correct / total
        
        # 验证
        model.eval()
        val_correct = 0
        val_total = 0
        val_predictions = []
        val_true_labels = []
        
        with torch.no_grad():
            for batch in val_loader:
                input_ids = batch['input_ids'].to(device)
                attention_mask = batch['attention_mask'].to(device)
                labels = batch['labels'].to(device)
                
                outputs = model(input_ids, attention_mask)
                _, predicted = torch.max(outputs, 1)
                
                val_total += labels.size(0)
                val_correct += (predicted == labels).sum().item()
                val_predictions.extend(predicted.cpu().numpy())
                val_true_labels.extend(labels.cpu().numpy())
        
        val_accuracy = val_correct / val_total
        val_f1 = f1_score(val_true_labels, val_predictions, average='weighted')
        
        # 计算每个级别的准确率
        val_true_labels = np.array(val_true_labels)
        val_predictions = np.array(val_predictions)
        
        level_names = ['HSK1', 'HSK2', 'HSK3', 'HSK4', 'HSK5', 'HSK6', 'HSK7-9']
        level_accuracies = []
        for i in range(7):
            mask = val_true_labels == i
            if np.sum(mask) > 0:
                level_acc = np.mean(val_predictions[mask] == val_true_labels[mask])
                level_accuracies.append(level_acc)
        
        print(f'\nEpoch {epoch+1}:')
        print(f'  训练损失: {avg_loss:.4f}, 训练准确率: {train_accuracy:.4f}')
        print(f'  验证准确率: {val_accuracy:.4f}, 验证F1: {val_f1:.4f}')
        print(f'  级别准确率: {[f"{acc:.3f}" for acc in level_accuracies]}')
        
        # 保存最佳模型
        if val_accuracy > best_accuracy:
            best_accuracy = val_accuracy
            best_epoch = epoch + 1
            patience_counter = 0
            checkpoint = {
                'model_state_dict': model.state_dict(),
                'config': model_config,
                'accuracy': best_accuracy,
                'epoch': best_epoch,
            }
            torch.save(checkpoint, 'best_optimized_model.pth')
            # 保存分词器
            save_tokenizer(tokenizer, 'best_optimized_model_tokenizer.pkl')
            print(f'  ✅ 保存最佳模型: {best_accuracy:.4f}')
        else:
            patience_counter += 1
            print(f'  ⏳ 耐心计数: {patience_counter}/{patience}')
        
        # 动态学习率调整
        if patience_counter >= 8:
            old_lr = optimizer.param_groups[0]['lr']
            new_lr = old_lr * 0.5
            optimizer.param_groups[0]['lr'] = new_lr
            patience_counter = 6
            print(f'  🔄 调整学习率: {old_lr:.2e} -> {new_lr:.2e}')
        
        # 早停
        if patience_counter >= patience:
            print(f"⏹️ 早停触发，最佳验证准确率: {best_accuracy:.4f} (第{best_epoch}轮)")
            break
    
    # 测试
    print("加载最佳模型进行测试...")
    checkpoint = torch.load('best_optimized_model.pth', weights_only=False)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    
    test_correct = 0
    test_total = 0
    all_predictions = []
    all_labels = []
    
    with torch.no_grad():
        for batch in test_loader:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)
            
            outputs = model(input_ids, attention_mask)
            _, predicted = torch.max(outputs, 1)
            
            test_total += labels.size(0)
            test_correct += (predicted == labels).sum().item()
            
            all_predictions.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    test_accuracy = test_correct / test_total
    test_f1 = f1_score(all_labels, all_predictions, average='weighted')
    
    print(f"\n🎯 最终测试结果:")
    print(f"测试集准确率: {test_accuracy:.4f}")
    print(f"测试集F1分数: {test_f1:.4f}")
    print(f"最佳验证准确率: {best_accuracy:.4f} (第{best_epoch}轮)")
    
    print("\n详细分类报告:")
    print(classification_report(all_labels, all_predictions, 
                              target_names=['HSK1', 'HSK2', 'HSK3', 'HSK4', 'HSK5', 'HSK6', 'HSK7-9'],
                              digits=4))
    
    return model, tokenizer, test_accuracy

# ==================== 使用示例 ====================
def demo_prediction():
    """演示预测功能"""
    print("\n" + "="*50)
    print("🎯 HSK文本分级预测演示")
    print("="*50)
    
    # 创建预测器
    predictor = HSKTextPredictor('best_optimized_model.pth')
    
    # 测试文本
    test_texts = [
        "今天天气很好，我想去公园散步。",
        "学习汉语需要坚持不懈的努力和正确的方法。",
        "随着人工智能技术的快速发展，自然语言处理在多个领域展现出巨大的应用潜力。",
        "在全球化背景下，跨文化交际能力已成为现代人才必备的核心素养之一。"
    ]
    
    for i, text in enumerate(test_texts, 1):
        print(f"\n📝 示例 {i}:")
        print(f"文本: {text}")
        
        try:
            result = predictor.predict_text(text)
            print(f"📊 分级结果:")
            print(f"  预测级别: {result['predicted_level']}")
            print(f"  置信度: {result['confidence']:.2%}")
            print("  各级别概率:")
            for level, prob in result['probabilities'].items():
                print(f"    {level}: {prob:.2%}")
        except Exception as e:
            print(f"  ❌ 错误: {str(e)}")

if __name__ == "__main__":
    print("开始优化的HSK分级模型训练...")
    model, tokenizer, accuracy = train_optimized_model()
    
    print(f"\n📈 最终准确率: {accuracy:.4f}")
    
    # 训练完成后演示预测功能
    demo_prediction()
    
    print(f"\n💡 使用说明:")
    print("1. 训练完成后会生成 'best_optimized_model.pth' 和 'best_optimized_model_tokenizer.pkl'")
    print("2. 在其他程序中使用:")
    print("   predictor = HSKTextPredictor('best_optimized_model.pth')")
    print("   result = predictor.predict_text('你的中文文本')")
    print("3. 结果包含预测级别、置信度和各级别概率")